# JARVIS: projeto para publicar na Google Play

Esta pasta tem o JARVIS pronto como app instalável (PWA). Ele funciona no navegador, instala na tela inicial e pode ser empacotado para a Google Play sem programar em Android.

## O que tem aqui

- `web/index.html`: o app inteiro. Funciona sem chave de API (comandos locais, clima, Wikipédia, cotação, notas, alarmes no Relógio, atalhos de apps). A chave da Anthropic é opcional, só para conversa livre.
- `web/manifest.webmanifest`, `web/sw.js`, `web/icons/`: o que faz virar app instalável.
- `web/privacy.html`: política de privacidade. Preencha `[SEU NOME]`, `[SEU E-MAIL]` e `[DATA]`. A Google Play exige esse endereço.
- `web/.well-known/assetlinks.json`: modelo para ligar o site ao app (passo 4).
- `.github/workflows/pages.yml`: publica a pasta `web` no GitHub Pages sozinho.

## Passo 1: colocar no ar em https

1. Crie uma conta e um repositório público no GitHub (por exemplo, `jarvis`).
2. Envie o conteúdo desta pasta para o repositório. Pelo site do GitHub, use Add file > Upload files e arraste tudo, mantendo as subpastas. É mais fácil de um computador, porque no celular o envio de pastas costuma falhar.
3. Em Settings > Pages, escolha Source: GitHub Actions. Em poucos minutos o endereço `https://SEUUSUARIO.github.io/jarvis/` fica no ar.
4. Abra o endereço no Chrome do celular e teste: o menu do Chrome deve oferecer "Instalar app".

## Passo 2: gerar o app para a Google Play

1. Acesse pwabuilder.com e cole o endereço do passo 1.
2. Se ele apontar algum problema, corrija e rode de novo.
3. Escolha Package for stores > Android e preencha: nome `JARVIS`, ID do pacote (por exemplo `br.com.seunome.jarvis`), versão 1.
4. Em Signing key, escolha "Create new" e **guarde o arquivo da chave e as senhas**. Sem eles você não consegue publicar atualizações.
5. Baixe o pacote. Ele traz o arquivo `.aab`, que é o formato aceito pela Google Play, e o `assetlinks.json` preenchido.

## Passo 3: ligar o app ao site

Troque o conteúdo de `web/.well-known/assetlinks.json` pelo gerado pelo PWABuilder (ou preencha o pacote e a impressão SHA-256 do modelo), envie de novo ao GitHub e confirme que abre em `https://SEUUSUARIO.github.io/jarvis/.well-known/assetlinks.json`. Sem isso, o app mostra uma barra de endereço do navegador por cima.

Atenção: o assetlinks precisa ficar na raiz do domínio. Em `usuario.github.io/jarvis/` ele fica numa subpasta, e isso pode não ser aceito. Se der problema, use um domínio próprio ou um repositório chamado `SEUUSUARIO.github.io`, que serve a raiz.

## Passo 4: publicar na Google Play

1. Crie a conta em play.google.com/console (taxa única de cerca de 25 dólares e verificação de identidade).
2. Crie o app, envie o `.aab` e preencha: descrição, ícone 512x512 (`web/icons/icon-512.png`), capturas de tela, classificação de conteúdo, público-alvo e a **política de privacidade** (`.../privacy.html`).
3. Em Segurança dos dados, declare: microfone usado pelo reconhecimento de voz; áudio processado por serviço de terceiros; nada coletado ou enviado a servidor próprio.
4. Contas pessoais novas costumam precisar de um teste fechado com testadores antes de liberar ao público. Confira as regras atuais no painel.
5. Envie para análise.

## Textos sugeridos para a loja

- **Título:** JARVIS: assistente por voz
- **Descrição curta (até 80 caracteres):** Assistente pessoal por voz e texto: alarmes, notas, clima e apps.
- **Descrição completa:** O JARVIS é um assistente pessoal com interface futurista. Fale ou digite para criar alarmes e timers, anotar coisas, ver o clima, consultar a Wikipédia, converter moedas e abrir seus aplicativos favoritos. Funciona sem conta. Seus dados ficam no seu aparelho.

## Limites que você precisa saber

- **Este app só escuta enquanto está aberto na tela.** Um app empacotado a partir de um site não consegue ficar ouvindo "Jarvis" em segundo plano nem com a tela bloqueada. O Android não permite isso para páginas web.
- Para atender "Jarvis" de qualquer lugar, é preciso um app Android nativo, com um serviço em primeiro plano (uma notificação fixa) e uma palavra de ativação. A Google Play também exige declarações extras para esse tipo de uso do microfone. É um projeto separado.
- O reconhecimento de voz depende do navegador ou do Android e pode enviar o áudio para o fornecedor.
- Alarmes e timers abrem o app Relógio do Android, e você confirma por lá.
- Eu não consegui compilar nem testar o app dentro do Android. O que foi testado é a página no navegador.
